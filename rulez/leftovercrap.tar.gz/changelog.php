<?
require("include/top.php");

if($login&&$password&&$version&&$comment) {
  if(CheckLogin($login,$password,"administrator")) {
    $query="INSERT changelog SET version='".$version."',comment='".$comment."',quand=NOW()";
    mysql_query($query);
  }
}

$query="SELECT version,comment FROM changelog ORDER BY quand DESC LIMIT 1";
$result=mysql_query($query);
$changelog=mysql_fetch_array($result);
?>
<form action="changelog.php">
<table>
 <tr>
  <td><b>login:</b></td>
  <td><input type="text" name="login" value="<? print($login); ?>" size="10"></td>
 </tr>
 <tr>
  <td><b>password:</b></td>
  <td><input type="password" name="password" size="10"></td>
 </tr>
 <tr>
  <td><b>version:</b></td>
  <td><input type="text" name="version" value="<? print($changelog["version"]); ?>" size="5"></td>
 </tr>
 <tr>
  <td><b>comment:</b></td>
  <td><input type="text" name="comment" value="<? print($changelog["comment"]); ?>" size="40"></td>
 </tr>
 <tr><td colspan="2"><input type="submit"></td></tr>
</form>
<? require("include/bottom.php"); ?>
