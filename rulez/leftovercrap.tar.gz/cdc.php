<?
require("include/top.php");

if($quand_y&&$quand_m&&$quand_d&&$id)
{
	$query="INSERT INTO cdc SET which=".$id.", quand='".$quand_y."-".$quand_m."-".$quand_d."'";
	mysql_query($query);
}

$query="SELECT cdc.which,cdc.quand,prods.name FROM cdc,prods WHERE cdc.which=prods.id ORDER BY quand DESC";
$result=mysql_query($query);
while($tmp=mysql_fetch_assoc($result))
	$cdc[]=$tmp;
?>
<table>
	<tr>
		<th><b>name of the prod</b></th>
		<th><b>was coup de coeur on the</b></th>
	</tr>
	<form method="post">
		<tr>
			<td>prod ID: <input type="text" name="id" size="6"></td>
			<td>
				<select name="quand_y">
					<option>2001
					<option>2002
					<option>2003
				</select>
				<select name="quand_m">
					<option>01
					<option>02
					<option>03
					<option>04
					<option>05
					<option>06
					<option>07
					<option>08
					<option>09
					<option>10
					<option>11
					<option>12
				</select>
				<select name="quand_d">
					<option>01
					<option>15
				</select>
				<input type="submit" value="add">
			</td>
		</tr>
	</form>
	<? for($i=0;$i<count($cdc);$i++): ?>
		<tr>
			<td><a href="http://www.pouet.net/prod.php?which=<?=$cdc[$i]["which"]?>"><?=$cdc[$i]["name"]?></a></td>
			<td align="center"><?=$cdc[$i]["quand"]?></td>
		</tr>
	<? endfor; ?>
	<form method="post">
		<tr>
			<td>prod ID: <input type="text" name="id" size="6"></td>
			<td>
				<select name="quand_y">
					<option>2001
					<option>2002
				</select>
				<select name="quand_m">
					<option>01
					<option>02
					<option>03
					<option>04
					<option>05
					<option>06
					<option>07
					<option>08
					<option>09
					<option>10
					<option>11
					<option>12
				</select>
				<select name="quand_d">
					<option>01
					<option>15
				</select>
				<input type="submit" value="add">
			</td>
		</tr>
	</form>
</table>

<? require("include/bottom.php"); ?>
