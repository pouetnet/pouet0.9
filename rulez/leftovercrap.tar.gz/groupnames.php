<?

require("../include/top.php");

  $sql = "SELECT name from groups";
  $r = mysql_query($sql);
  while ($o = mysql_fetch_object($r)) {
    echo "<br />".$o->name;
  }

?>