<?
session_start();
phpinfo();
?>