<?
session_start();
if (!($SESSION_LEVEL=='administrator' || $SESSION_LEVEL=='moderator' || $SESSION_LEVEL=='gloperator'))
  die("OMG");
	require("../include/top.php");

$sql = "SELECT * FROM users where nickname=''";
$r = mysql_query($sql);
while($o = mysql_fetch_object($r)) {
  $returnvalue = $xml->parseSceneIdData("getUserInfo", array("userID" => $o->id)); 
  var_dump($returnvalue["user"]["nickname"]);
  $r2 = mysql_query_debug("update users set nickname='".addslashes($returnvalue["user"]["nickname"])."' WHERE id=".$o->id); 
}
//  printf("<iframe src='../user.php?who=".$o->id."'></iframe>");

	require("../include/bottom.php");
?>