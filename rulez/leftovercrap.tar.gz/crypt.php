<form>
<input type="text" name="dbpassword" value="<?=$dbpassword?>" />
<input type="submit" />
</form>
<?
$key = substr($dbpassword,0,2);
print(crypt($dbpassword));
?>