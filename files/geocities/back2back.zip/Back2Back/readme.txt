ABOUT BACK2BACK:
----------------
It's coded in 2004 summer and because of Java's Audio system
it is released in January 2005.
I tried to give a real oldskool look and feeling.

I didn't use Java2d classes, they are great for this
kind of stuff but it was too late when I discovered them.
I used default swing & awt classes. They are little slow.
By the way Java is very weak in playing Audio.

Demo is ~ 4.30 minute.   

Code / gfx by me  (tesla)

Music: 
Slowhand/HI3s     insane.au, lotus.au, homework.au
Leonard/OXYGENE   nostalgic.au

Special thanks to HI3s, good luck on your projects :)


Help & Problems:
----------------
Run the html file to see demo.

if you are using Windows XP with service pack 2 
you must give permission to run the program . You will 
see the yellow line informing you about the applet.

It works in Linux too but fonts are different
in Linux and system clock hit is also doesn't match
with Windows's. So this makes the demo unsynchronous.
If i get good suggestions about the demo, i will make a
linux version.

If you have JRE and it still doesn't work put demo folder
under JRE folder.

Don't press refresh button in execution time. A clone of the
demo will work in the backround if you do so...!

For more help contact me star_gate_85@yahoo.co.uk


System Requirements:
--------------------
JRE must be installed. You can find it at http://java.sun.com/
Will work on every computer.

Works perfect on --- My system :)
2.4GHZ
512 MB ram
Windows XP with sercive pack2
  



Thats All see you later...       