.

by

nun



an entry for the blitz2d tech demo contest
3rd release version


design by blunder
music by stuntel
code by blunder
lyrics by kmfdm


system requirements:
wintel pc
fast processor
lots of ram
32mb videocard
monitor
keyboard
power cord


this demo was as always finished in a hurry
the graphics suck because i can't be arsed
to pixel for a pc demo- you'll have to live
with my photoshop lameness unless you get a
brain and buy an atari


contact us:
suckingrhinocock@yahoo.co.in
we accept creditcards for large amounts