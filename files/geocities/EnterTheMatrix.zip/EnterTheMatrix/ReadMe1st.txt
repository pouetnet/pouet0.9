About confirmation question:
----------------------------
When you execute the demo a confirmation question will
appear.
I have packed wav files with trial version of "molebox"
so it says "this is trial version... Are you sure want
to execute this file...ble bla bla". You must press "Yes"
if you want to see the demo. It is not a trojan or a virus
If you don't trust me just delete the demo, and stop reading my txt  


To get the best visuals:
-----------------------
Set your console aplication window size 125 to 60
You can do it like this;
* open a console application
* right click on the window bar
* set window size X=125 Y=60
* or do it yourself with mouse

caution: Pressing ALT+ENTER is not recomended!!!
It makes the text too big.

If your monitor is below 15", demo will work with
the worst visuals...(tested)
Buying a 17" monitor will solve this problem. 


System Requirements:
--------------------
Nothing, just a pc 


Known Problems:
---------------
In some computers, it works too fast. All those
matrix lines flow very fast. However in my computer 
it works perfectly.